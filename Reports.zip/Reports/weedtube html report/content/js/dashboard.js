/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 96.0, "KoPercent": 4.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.5909090909090909, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "Upload video"], "isController": false}, {"data": [0.25, 500, 1500, "Top Videos"], "isController": false}, {"data": [0.5, 500, 1500, "Articles"], "isController": false}, {"data": [0.5, 500, 1500, "Smoke Rings"], "isController": false}, {"data": [0.5, 500, 1500, "Login-0"], "isController": false}, {"data": [0.5, 500, 1500, "Login-1"], "isController": false}, {"data": [0.5, 500, 1500, "Notification"], "isController": false}, {"data": [0.5, 500, 1500, "Making the Ultimate Slow-Burning Cannabis Cigar | BONG APPETIT"], "isController": false}, {"data": [0.5, 500, 1500, "Registration"], "isController": true}, {"data": [1.0, 500, 1500, "Shorts"], "isController": false}, {"data": [0.5, 500, 1500, "Search Weed Keyword"], "isController": false}, {"data": [0.5, 500, 1500, "User Registration"], "isController": false}, {"data": [1.0, 500, 1500, "Publish"], "isController": false}, {"data": [1.0, 500, 1500, "Purchase"], "isController": true}, {"data": [0.5, 500, 1500, "Weedtube Homepage and Search"], "isController": true}, {"data": [1.0, 500, 1500, "User Registration-0"], "isController": false}, {"data": [1.0, 500, 1500, "Publish-1"], "isController": false}, {"data": [0.5, 500, 1500, "Elevate-your-smoke-game-with-getglass-bong-waterpipe"], "isController": false}, {"data": [1.0, 500, 1500, "Publish-0"], "isController": false}, {"data": [0.5, 500, 1500, "User Registration-1"], "isController": false}, {"data": [0.0, 500, 1500, "Login"], "isController": false}, {"data": [0.0, 500, 1500, "Upload Shorts"], "isController": true}, {"data": [0.5, 500, 1500, "Publish Article"], "isController": false}, {"data": [1.0, 500, 1500, "Purchase video"], "isController": false}, {"data": [1.0, 500, 1500, "Top Videos-0"], "isController": false}, {"data": [0.5, 500, 1500, "Top Videos-1"], "isController": false}, {"data": [0.5, 500, 1500, "TheWeedTube-Homepage"], "isController": false}, {"data": [1.0, 500, 1500, "Weedtube Search"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 25, 1, 4.0, 569.8, 6, 2176, 519.0, 1094.6000000000008, 1928.7999999999993, 2176.0, 1.9655633304505074, 76.42716789350578, 9.462882179220065], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Upload video", 1, 1, 100.0, 6.0, 6, 6, 6.0, 6.0, 6.0, 6.0, 166.66666666666666, 420.0846354166667, 0.0], "isController": false}, {"data": ["Top Videos", 2, 0, 0.0, 1737.5, 923, 2552, 1737.5, 2552.0, 2552.0, 2552.0, 0.7836990595611285, 133.96508865595612, 3.4095501077586206], "isController": false}, {"data": ["Articles", 2, 0, 0.0, 921.0, 615, 1227, 921.0, 1227.0, 1227.0, 1227.0, 1.6299918500407498, 88.17953468826406, 71.56444198247758], "isController": false}, {"data": ["Smoke Rings", 1, 0, 0.0, 507.0, 507, 507, 507.0, 507.0, 507.0, 507.0, 1.9723865877712032, 129.3531188362919, 2.457778599605523], "isController": false}, {"data": ["Login-0", 1, 0, 0.0, 1352.0, 1352, 1352, 1352.0, 1352.0, 1352.0, 1352.0, 0.7396449704142012, 0.48755894045857984, 0.9585047614644969], "isController": false}, {"data": ["Login-1", 1, 0, 0.0, 824.0, 824, 824, 824.0, 824.0, 824.0, 824.0, 1.2135922330097086, 80.9029884708738, 1.4672140473300972], "isController": false}, {"data": ["Notification", 1, 0, 0.0, 615.0, 615, 615, 615.0, 615.0, 615.0, 615.0, 1.6260162601626016, 1.1861661585365855, 2.105564024390244], "isController": false}, {"data": ["Making the Ultimate Slow-Burning Cannabis Cigar | BONG APPETIT", 1, 0, 0.0, 503.0, 503, 503, 503.0, 503.0, 503.0, 503.0, 1.9880715705765406, 146.12520191351888, 2.5724558896620278], "isController": false}, {"data": ["Registration", 1, 0, 0.0, 809.0, 809, 809, 809.0, 809.0, 809.0, 809.0, 1.2360939431396785, 83.24802997527811, 3.1747334672435104], "isController": true}, {"data": ["Shorts", 1, 0, 0.0, 206.0, 206, 206, 206.0, 206.0, 206.0, 206.0, 4.854368932038835, 312.70384557038835, 5.982630461165049], "isController": false}, {"data": ["Search Weed Keyword", 1, 0, 0.0, 578.0, 578, 578, 578.0, 578.0, 578.0, 578.0, 1.7301038062283738, 104.77434310121107, 2.1237700043252596], "isController": false}, {"data": ["User Registration", 1, 0, 0.0, 809.0, 809, 809, 809.0, 809.0, 809.0, 809.0, 1.2360939431396785, 83.24802997527811, 3.1747334672435104], "isController": false}, {"data": ["Publish", 1, 0, 0.0, 434.0, 434, 434, 434.0, 434.0, 434.0, 434.0, 2.304147465437788, 2.7406754032258065, 6.7009288594470044], "isController": false}, {"data": ["Purchase", 2, 0, 0.0, 250.0, 197, 303, 250.0, 303.0, 303.0, 303.0, 3.976143141153081, 215.67470178926442, 4.896402833001988], "isController": true}, {"data": ["Weedtube Homepage and Search", 1, 0, 0.0, 1379.0, 1379, 1379, 1379.0, 1379.0, 1379.0, 1379.0, 0.7251631617113851, 92.71961679659174, 2.9835082034082667], "isController": true}, {"data": ["User Registration-0", 1, 0, 0.0, 190.0, 190, 190, 190.0, 190.0, 190.0, 190.0, 5.263157894736842, 3.4693667763157894, 7.154605263157895], "isController": false}, {"data": ["Publish-1", 1, 0, 0.0, 202.0, 202, 202, 202.0, 202.0, 202.0, 202.0, 4.9504950495049505, 3.8772431930693068, 6.2848081683168315], "isController": false}, {"data": ["Elevate-your-smoke-game-with-getglass-bong-waterpipe", 1, 0, 0.0, 619.0, 619, 619, 619.0, 619.0, 619.0, 619.0, 1.6155088852988693, 121.35721678109854, 2.0777589862681745], "isController": false}, {"data": ["Publish-0", 1, 0, 0.0, 231.0, 231, 231, 231.0, 231.0, 231.0, 231.0, 4.329004329004329, 1.7586580086580086, 7.093817640692641], "isController": false}, {"data": ["User Registration-1", 1, 0, 0.0, 619.0, 619, 619, 619.0, 619.0, 619.0, 619.0, 1.6155088852988693, 107.73582643376413, 1.953125], "isController": false}, {"data": ["Login", 2, 0, 0.0, 2176.0, 2176, 2176, 2176.0, 2176.0, 2176.0, 2176.0, 0.9182736455463728, 61.82115903351699, 2.3001678719008267], "isController": false}, {"data": ["Upload Shorts", 1, 1, 100.0, 1261.0, 1261, 1261, 1261.0, 1261.0, 1261.0, 1261.0, 0.7930214115781126, 54.60463545796987, 4.310505055511499], "isController": true}, {"data": ["Publish Article", 1, 0, 0.0, 612.0, 612, 612, 612.0, 612.0, 612.0, 612.0, 1.6339869281045751, 1.2015548406862746, 139.49365553513073], "isController": false}, {"data": ["Purchase video", 2, 0, 0.0, 250.0, 197, 303, 250.0, 303.0, 303.0, 303.0, 3.9840637450199203, 216.1043326693227, 4.906156623505976], "isController": false}, {"data": ["Top Videos-0", 1, 0, 0.0, 404.0, 404, 404, 404.0, 404.0, 404.0, 404.0, 2.4752475247524752, 0.8798731435643564, 3.016707920792079], "isController": false}, {"data": ["Top Videos-1", 1, 0, 0.0, 519.0, 519, 519, 519.0, 519.0, 519.0, 519.0, 1.9267822736030829, 122.31680515414257, 2.348265895953757], "isController": false}, {"data": ["TheWeedTube-Homepage", 1, 0, 0.0, 617.0, 617, 617, 617.0, 617.0, 617.0, 617.0, 1.6207455429497568, 107.88562348055106, 1.9594560372771475], "isController": false}, {"data": ["Weedtube Search", 1, 0, 0.0, 184.0, 184, 184, 184.0, 184.0, 184.0, 184.0, 5.434782608695652, 3.996475883152174, 9.11812160326087], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.io.FileNotFoundException/Non HTTP response message: C:\\\\Users\\\\tanuj\\\\Downloads\\\\TS.mp4 (The system cannot find the file specified)", 1, 100.0, 4.0], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 25, 1, "Non HTTP response code: java.io.FileNotFoundException/Non HTTP response message: C:\\\\Users\\\\tanuj\\\\Downloads\\\\TS.mp4 (The system cannot find the file specified)", 1, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["Upload video", 1, 1, "Non HTTP response code: java.io.FileNotFoundException/Non HTTP response message: C:\\\\Users\\\\tanuj\\\\Downloads\\\\TS.mp4 (The system cannot find the file specified)", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
