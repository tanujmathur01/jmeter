/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 76.10675039246468, "KoPercent": 23.89324960753532};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7183673469387755, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.75, 500, 1500, "Get Product Category list"], "isController": false}, {"data": [0.7142857142857143, 500, 1500, "Search  Product"], "isController": false}, {"data": [0.7534965034965035, 500, 1500, "Get Product Category"], "isController": false}, {"data": [0.7703180212014135, 500, 1500, "Update  Product"], "isController": false}, {"data": [0.36666666666666664, 500, 1500, "Get Products"], "isController": false}, {"data": [0.7576271186440678, 500, 1500, "Get Single  Product"], "isController": false}, {"data": [0.7542662116040956, 500, 1500, "Limit & Skip Product"], "isController": false}, {"data": [0.7302405498281787, 500, 1500, "Sort  Product"], "isController": false}, {"data": [0.7597173144876325, 500, 1500, "Delete  Product"], "isController": false}, {"data": [0.7899305555555556, 500, 1500, "Get all Product Categories"], "isController": false}, {"data": [0.7711267605633803, 500, 1500, "Add New Product"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 3185, 761, 23.89324960753532, 296.6882260596545, 19, 3448, 213.0, 616.0, 1035.0, 1147.1399999999999, 53.38764289785109, 651.9488558743169, 8.188487529962453], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Get Product Category list", 288, 72, 25.0, 211.89930555555543, 95, 477, 209.0, 224.0, 229.0, 287.32000000000016, 5.022321428571429, 6.959097726004464, 0.6672654833112444], "isController": false}, {"data": ["Search  Product", 294, 78, 26.53061224489796, 254.38775510204067, 22, 2010, 215.0, 409.0, 436.0, 824.7000000000006, 5.046950371654679, 141.44066011085266, 0.6778419673664876], "isController": false}, {"data": ["Get Product Category", 286, 70, 24.475524475524477, 222.16083916083923, 19, 675, 212.0, 230.0, 248.0, 448.65, 5.011652969316768, 102.2603844494191, 0.6998352813359735], "isController": false}, {"data": ["Update  Product", 283, 65, 22.968197879858657, 211.47349823321548, 198, 285, 209.0, 225.0, 230.0, 247.60000000000025, 5.010711946033038, 7.704190938224827, 1.0471605043467485], "isController": false}, {"data": ["Get Products", 300, 74, 24.666666666666668, 996.3733333333331, 44, 3448, 1037.0, 1143.0, 1174.95, 3303.1100000000015, 5.029675082989638, 169.60815884028267, 0.5940812512574187], "isController": false}, {"data": ["Get Single  Product", 295, 71, 24.06779661016949, 215.44745762711864, 86, 937, 211.0, 224.40000000000003, 229.39999999999998, 309.880000000003, 5.037654331528885, 11.323465569980703, 0.6128634688946192], "isController": false}, {"data": ["Limit & Skip Product", 293, 72, 24.573378839590443, 212.86006825938566, 92, 276, 212.0, 225.0, 231.3, 254.90000000000003, 5.048155614134835, 7.911820281137472, 0.7784940010079082], "isController": false}, {"data": ["Sort  Product", 291, 66, 22.68041237113402, 270.87628865979394, 94, 2289, 216.0, 269.20000000000016, 655.4, 2148.999999999998, 5.031468289646587, 188.38116208978838, 0.7099816723148212], "isController": false}, {"data": ["Delete  Product", 283, 68, 24.02826855123675, 211.26501766784446, 173, 246, 209.0, 224.0, 228.8, 237.48000000000008, 5.013374904781307, 11.48295225557583, 1.0293791187620684], "isController": false}, {"data": ["Get all Product Categories", 288, 60, 20.833333333333332, 216.18750000000003, 197, 1361, 210.0, 225.0, 231.0, 277.9900000000001, 5.009479744655685, 15.315814377467778, 0.6555373884608026], "isController": false}, {"data": ["Add New Product", 284, 65, 22.887323943661972, 211.40140845070417, 127, 286, 209.0, 225.0, 231.0, 238.19999999999982, 4.9953388563488295, 5.664725531194484, 1.0256886454980387], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 18, 2.3653088042049935, 0.565149136577708], "isController": false}, {"data": ["429/Too Many Requests", 743, 97.634691195795, 23.328100470957615], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 3185, 761, "429/Too Many Requests", 743, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 18, "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["Get Product Category list", 288, 72, "429/Too Many Requests", 70, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 2, "", "", "", "", "", ""], "isController": false}, {"data": ["Search  Product", 294, 78, "429/Too Many Requests", 77, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["Get Product Category", 286, 70, "429/Too Many Requests", 68, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 2, "", "", "", "", "", ""], "isController": false}, {"data": ["Update  Product", 283, 65, "429/Too Many Requests", 65, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Get Products", 300, 74, "429/Too Many Requests", 69, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 5, "", "", "", "", "", ""], "isController": false}, {"data": ["Get Single  Product", 295, 71, "429/Too Many Requests", 70, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["Limit & Skip Product", 293, 72, "429/Too Many Requests", 70, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 2, "", "", "", "", "", ""], "isController": false}, {"data": ["Sort  Product", 291, 66, "429/Too Many Requests", 63, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 3, "", "", "", "", "", ""], "isController": false}, {"data": ["Delete  Product", 283, 68, "429/Too Many Requests", 67, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["Get all Product Categories", 288, 60, "429/Too Many Requests", 60, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Add New Product", 284, 65, "429/Too Many Requests", 64, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
